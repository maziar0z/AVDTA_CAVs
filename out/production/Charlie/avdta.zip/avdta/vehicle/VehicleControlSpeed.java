package avdta.vehicle;

public class VehicleControlSpeed
{
    // public void
}
