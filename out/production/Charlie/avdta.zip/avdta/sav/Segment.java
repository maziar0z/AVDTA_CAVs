/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package avdta.sav;

import avdta.network.Path;

/**
 *
 * @author pv5345
 */
public class Segment extends Path
{
    private int dtime, etime;
}
